import React, { useState, useEffect } from "react";
import PageBreadcrumb from "../../components/PageBreadcrumb";
import { Row, Col, Form, Container, Card, Button } from "react-bootstrap";
import { decodeJwt } from "../../utils/decode-jwt";
import Swal from 'sweetalert2';

const BASE_URL = "http://localhost:5100/api";

const Toast = Swal.mixin({
  toast: true,
  position: 'top-end',
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener('mouseenter', Swal.stopTimer)
    toast.addEventListener('mouseleave', Swal.resumeTimer)
  }
});

const AddInvoice = () => {
  const initialFormData = {
    invoice_id: "",
    admission_no: "",
    patient_id: "",
    discharge_date: "",
    dischargetime: "",
    bed_category: "",
    admission_date: "",
    admissiontime: "",
    consultantName: "",
    surgeonName: "",
    Sub_Total: "0.00",
    bill_Type: "",
    bill_method: "",
    note: "",
    dynamicRows: [{ label: "", value: "" }],
    discount: "",
    discountAmount: "",
    payableAmount: "0.00",
    chequeno: "",
    pdc: "",
    reimbursement: "",
    insurance: "",
    tpa: "",
  };

  const [formData, setFormData] = useState(initialFormData);
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [consultants, setConsultants] = useState([]);
  const [surgeons, setSurgeons] = useState([]);
  const [insurance, setInsurance] = useState([]);
  const [tpa, setTpa] = useState([]);
  const [currentLocation, setCurrentLocation] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      const payload = decodeJwt(token);
      if (payload && payload.jobLocation) {
        setCurrentLocation(payload.jobLocation);
      }
    }
  }, []);

  useEffect(() => {
    if (!currentLocation) return;

    const fetchDropdowns = async () => {
      try {
        const [cRes, sRes, iRes, tRes] = await Promise.all([
          fetch(`${BASE_URL}/V1/invoice/consultant_dropdown?location=${currentLocation}`),
          fetch(`${BASE_URL}/V1/invoice/surgeon_dropdown?location=${currentLocation}`),
          fetch(`${BASE_URL}/V1/invoice/insurance_co_dropdown?location=${currentLocation}`),
          fetch(`${BASE_URL}/V1/invoice/tpa_dropdown?location=${currentLocation}`)
        ]);

        const [c, s, i, t] = await Promise.all([
          cRes.json(), sRes.json(), iRes.json(), tRes.json()
        ]);

        if (cRes.ok) setConsultants(c.data ?? []);
        if (sRes.ok) setSurgeons(s.data ?? []);
        if (iRes.ok) setInsurance(i.data ?? []);
        if (tRes.ok) setTpa(t.data ?? []);
      } catch (err) {
        console.error("Dropdown fetch failed:", err);
      }
    };

    fetchDropdowns();
  }, [currentLocation]);

  const validate = () => {
    const newErrors = {};
    const requiredFields = [
      "invoice_id",
      "admission_no",
      "patient_id",
      "discharge_date",
      "dischargetime",
      "bed_category",
      "admission_date",
      "admissiontime",
      "consultantName",
      "surgeonName",
      "Sub_Total",
      "bill_Type",
      "note",
    ];

    requiredFields.forEach((field) => {
      if (!formData[field]) {
        newErrors[field] = `${field.replace(/([A-Z])/g, " $1")} is required.`;
      }
    });

    return newErrors;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    let updatedFormData = { ...formData, [name]: value };

    if (name === "bill_Type") {
      updatedFormData.bill_method = "";
      updatedFormData.insurance = "";
      updatedFormData.tpa = "";
      updatedFormData.chequeno = "";
      updatedFormData.pdc = "";
      updatedFormData.discount = "";
      updatedFormData.discountAmount = "";
    }

    if (name === "bill_method" && value !== "PDC") {
      updatedFormData.chequeno = "";
      updatedFormData.pdc = "";
    }

    if (["discount", "pdc", "discountAmount", "Sub_Total", "bill_Type", "bill_method"].includes(name)) {
      const subTotal = parseFloat(updatedFormData.Sub_Total || 0);
      const discount = parseFloat(updatedFormData.discount || 0);
      const discountAmount = parseFloat(updatedFormData.discountAmount || 0);
      const pdc = parseFloat(updatedFormData.pdc || 0);

      let payable = subTotal;
      if (updatedFormData.bill_Type === "charity") {
        payable = subTotal - discountAmount;
      } else if (updatedFormData.bill_method === "PDC") {
        payable = subTotal - pdc;
      } else if (updatedFormData.bill_Type === "non_insurance") {
        payable = subTotal - discount;
      } else {
        payable = subTotal;
      }
      updatedFormData.payableAmount = Math.max(payable, 0).toFixed(2);
    }

    setFormData(updatedFormData);
  };

  const handleDynamicRowChange = (index, field, value) => {
    const updatedRows = formData.dynamicRows.map((row, i) =>
      i === index ? { ...row, [field]: value } : row
    );
    const newSubTotal = updatedRows.reduce((total, row) => total + (parseFloat(row.value) || 0), 0);

    setFormData({
      ...formData,
      dynamicRows: updatedRows,
      Sub_Total: newSubTotal.toFixed(2),
      payableAmount: newSubTotal.toFixed(2)
    });
  };


  const addDynamicRow = () => {
    setFormData({
      ...formData,
      dynamicRows: [...formData.dynamicRows, { label: "", value: "" }],
    });
  };

  // const deleteDynamicRow = (index) => {
  //   const updatedRows = formData.dynamicRows.filter((_, i) => i !== index);
  //   const newSubTotal = updatedRows.reduce((total, row) => total + (parseFloat(row.value) || 0), 0);
  //   setFormData({ ...formData, dynamicRows: updatedRows, Sub_Total: newSubTotal.toFixed(2) });
  // };

  const deleteDynamicRow = (index) => {
    if (formData.dynamicRows.length <= 1) return;

    const updatedRows = formData.dynamicRows.filter((_, i) => i !== index);
    const newSubTotal = updatedRows.reduce((total, row) => total + (parseFloat(row.value) || 0), 0);

    setFormData({
      ...formData,
      dynamicRows: updatedRows,
      Sub_Total: newSubTotal.toFixed(2),
      payableAmount: newSubTotal.toFixed(2) 
    });
  };

  const resetForm = () => {
    setFormData(initialFormData);
    setErrors({});
  };

  const getChargeBreakdown = () => {
    const subTotal = parseFloat(formData.Sub_Total) || 0;
    const discount = parseFloat(formData.discountAmount) || 0;
    const payable = subTotal - discount;

    return {
      subTotal: subTotal.toFixed(2),
      discount: discount.toFixed(2),
      payable: payable.toFixed(2)
    };
  };

  const handleReset = () => {
    resetForm();
    Toast.fire({
      icon: 'success',
      title: 'Form reset successful'
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const validationErrors = validate();
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setLoading(true);

      try {
        console.log(formData);
        const response = await fetch(`${BASE_URL}/V1/invoice/addInvoice?location=${currentLocation}`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        });

        const data = await response.json();

        if (response.ok) {
          Swal.fire({
            title: "Success!",
            text: "Invoice added successfully!",
            icon: "success",
            timer: 2000,
            showConfirmButton: true,
            confirmButtonText: "Okay",
            confirmButtonColor: "#00acc1"
          });
          resetForm();
        } else {
          Swal.fire({
            title: "Ops...",
            text: data.message || "Error adding invoice.",
            icon: "error",
          });
        }
      } catch (error) {
        Swal.fire({
          title: "Network Error",
          text: "Please check your connection and try again.",
          icon: "warning",
        });
      } finally {
        setLoading(false);
      }
    }
  };

  const sectionTitleStyle = {
    fontSize: "1.1rem",
    fontWeight: "600",
    color: "#00838f",
    paddingLeft: "5px",
    padding: "5px",
    marginBottom: "5px"
  };

  const cardStyle = {
    border: "none",
    borderRadius: "12px",
    paddingBottom: "10px",
    borderTop: "4px solid #00bcd4",
    boxShadow: "0 4px 12px rgba(0,0,0,0.05)",
    marginBottom: "10px",
    marginTop:"15px",
    backgroundColor: "#fff"
  };

  return (
    <div className="themebody-wrap" style={{background: "linear-gradient(to right, #e0f7fa, #80deea)", minHeight: "160vh", padding: "10px", paddingLeft: "30px" }}>
      <Container>
        <PageBreadcrumb pagename="Add New Invoice Form" />
        <Form onSubmit={handleSubmit}>
          <Card style={cardStyle}>
            <Card.Body className="p-4">
              <h5 style={sectionTitleStyle}>Patient & Admission Information</h5>
              <Row className="g-3">
                <Col md={4} className="mb-10">
                  <Form.Label className="small fw-bold text-muted">Invoice No <span className="text-danger">*</span></Form.Label>
                  <Form.Control name="invoice_id" style={{ border: '1px solid rgb(77, 208, 225)' }} value={formData.invoice_id} onChange={handleInputChange} isInvalid={errors.invoice_id} placeholder="Enter Invoice ID" />
                  <Form.Control.Feedback type="invalid">{errors.invoice_id}</Form.Control.Feedback>
                </Col>
                <Col md={4}>
                  <Form.Label className="small fw-bold text-muted">Admission No</Form.Label>
                  <Form.Control name="admission_no" style={{ border: '1px solid rgb(77, 208, 225)' }} value={formData.admission_no} onChange={handleInputChange} isInvalid={errors.admission_no} placeholder="Enter Admission No" />
                </Col>
                <Col md={4}>
                  <Form.Label className="small fw-bold text-muted">Patient ID <span className="text-danger">*</span></Form.Label>
                  <Form.Control name="patient_id" style={{ border: '1px solid rgb(77, 208, 225)' }} value={formData.patient_id} onChange={handleInputChange} isInvalid={errors.patient_id} placeholder="Enter Patient ID" />
                </Col>
                <Col md={3} className="mb-10">
                  <Form.Label className="small fw-bold text-muted">Admission Date <span className="text-danger">*</span></Form.Label>
                  <Form.Control type="date" style={{ border: '1px solid rgb(77, 208, 225)' }} name="admission_date" value={formData.admission_date} onChange={handleInputChange} isInvalid={errors.admission_date} />
                </Col>
                <Col md={3}>
                  <Form.Label className="small fw-bold text-muted">Admission Time <span className="text-danger">*</span></Form.Label>
                  <Form.Control type="time" style={{ border: '1px solid rgb(77, 208, 225)' }} name="admissiontime" value={formData.admissiontime} onChange={handleInputChange} isInvalid={errors.admissiontime} />
                </Col>
                <Col md={3}>
                  <Form.Label className="small fw-bold text-muted">Discharge Date <span className="text-danger">*</span></Form.Label>
                  <Form.Control type="date" style={{ border: '1px solid rgb(77, 208, 225)' }} name="discharge_date" min={formData.admission_date} value={formData.discharge_date} onChange={handleInputChange} isInvalid={errors.discharge_date} />
                </Col>
                <Col md={3}>
                  <Form.Label className="small fw-bold text-muted">Discharge Time <span className="text-danger">*</span></Form.Label>
                  <Form.Control type="time" style={{ border: '1px solid rgb(77, 208, 225)' }} name="dischargetime" value={formData.dischargetime} onChange={handleInputChange} />
                </Col>
                <Col md={4}>
                  <Form.Label className="small fw-bold text-muted">Bed Category <span className="text-danger">*</span></Form.Label>
                  <Form.Control name="bed_category" style={{ border: '1px solid rgb(77, 208, 225)' }} placeholder="Enter Bed Category" value={formData.bed_category} onChange={handleInputChange} isInvalid={errors.bed_category} />
                </Col>
                <Col md={4}>
                  <Form.Label className="small fw-bold text-muted">Consultant Name <span className="text-danger">*</span></Form.Label>
                  <Form.Select style={{ border: '1px solid rgb(77, 208, 225)' }} name="consultantName" value={formData.consultantName} onChange={handleInputChange} isInvalid={errors.consultantName}>
                    <option value="">SELECT CONSULTANT</option>
                    {consultants.map(c => <option key={c._id} value={c.name}>{c.name}</option>)}
                  </Form.Select>
                </Col>
                <Col md={4}>
                  <Form.Label className="small fw-bold text-muted">Surgeon Name</Form.Label>
                  <Form.Select style={{ border: '1px solid rgb(77, 208, 225)' }} name="surgeonName" value={formData.surgeonName} onChange={handleInputChange} isInvalid={errors.surgeonName}>
                    <option value="">SELECT SURGEON</option>
                    {surgeons.map((surgeon) => <option key={surgeon._id} value={surgeon.name}>{surgeon.name}</option>)}
                  </Form.Select>
                </Col>
              </Row>
            </Card.Body>
          </Card>

          <Card style={cardStyle}>
            <Card.Body className="p-4">
              <h5 style={sectionTitleStyle}>Billing Particulars</h5>

              {formData.dynamicRows.map((row, index) => (
                <Row key={index} className="align-items-end">
                  <Col md={5}>
                    <Form.Label className="small fw-bold text-muted">Label Name</Form.Label>
                    <Form.Control
                      style={{ border: '1px solid rgb(77, 208, 225)' }}
                      placeholder="e.g. Consultation Fees / Laboratory Charges"
                      value={row.label}
                      onChange={(e) => handleDynamicRowChange(index, "label", e.target.value)}
                    />
                  </Col>

                  <Col md={4}>
                    <Form.Label className="small fw-bold text-muted">Amount (₹)</Form.Label>
                    <Form.Control
                      style={{ border: '1px solid rgb(77, 208, 225)' }}
                      type="number"
                      placeholder="e.g. 500"
                      value={row.value}
                      onChange={(e) => handleDynamicRowChange(index, "value", e.target.value)}
                      onWheel={(e) => e.target.blur()}
                    />
                  </Col>

                  <Col md={3}> {/* Increased column width slightly to fit both */}
                    <div className="d-flex gap-2">
                      <Button
                        variant="outline-danger"
                        disabled={formData.dynamicRows.length <= 1}
                        onClick={() => deleteDynamicRow(index)}
                        style={{ whiteSpace: "nowrap" }}
                      >
                        - Delete Row
                      </Button>

                      <Button
                        variant="outline-success"
                        onClick={addDynamicRow}
                        style={{
                          whiteSpace: "nowrap",
                          borderStyle: "dashed",
                          borderWidth: "2px",
                          fontWeight: "600"
                        }}
                      >
                        + Add Row
                      </Button>
                    </div>
                  </Col>
                </Row>
              ))}
            </Card.Body>
          </Card>

          <Card style={{ ...cardStyle, borderTop: "4px solid #00bcd4" }}>
            <Card.Body className="p-4">
              <h5 style={sectionTitleStyle}>Payment Details & Config</h5>
              <Row className="g-4">
                <Col md={2}>
                  <Form.Label className="small fw-bold text-muted">Bill Type <span className="text-danger">*</span></Form.Label>
                  <Form.Select style={{ border: '1px solid rgb(77, 208, 225)' }} name="bill_Type" value={formData.bill_Type} onChange={handleInputChange} isInvalid={errors.bill_Type}>
                    <option value="">SELECT BILL TYPE</option>
                    <option value="insurance">Insurance</option>
                    <option value="non_insurance">Non-Insurance</option>
                    <option value="charity">Charity</option>
                  </Form.Select>
                </Col>

                {formData.bill_Type === "insurance" && (
                  <>
                    <Col md={5}>
                      <Form.Label className="small fw-bold text-muted">Insurance Company</Form.Label>
                      <Form.Select style={{ border: '1px solid rgb(77, 208, 225)' }} name="insurance" value={formData.insurance} onChange={handleInputChange}>
                        <option value="">CHOOSE INSURANCE</option>
                        {insurance.map(i => <option key={i._id} value={i.companyname}>{i.companyname}</option>)}
                      </Form.Select>
                    </Col>
                    <Col md={5}>
                      <Form.Label className="small fw-bold text-muted">TPA</Form.Label>
                      <Form.Select style={{ border: '1px solid rgb(77, 208, 225)' }} name="tpa" value={formData.tpa} onChange={handleInputChange}>
                        <option value="">SELECT TPA</option>
                        {tpa.map(t => <option key={t._id} value={t.companyname}>{t.companyname}</option>)}
                      </Form.Select>
                    </Col>
                    <Col md={4}>
                      <Form.Label className="small fw-bold text-muted">Bill Method</Form.Label>
                      <Form.Select style={{ border: '1px solid rgb(77, 208, 225)' }} name="bill_method" value={formData.bill_method} onChange={handleInputChange}>
                        <option value="">SELECT BILL METHOD</option>
                        <option value="cashless">Cashless</option>
                        <option value="PDC">PDC</option>
                        <option value="reimbursement">Reimbursement</option>
                      </Form.Select>
                    </Col>
                  </>
                )}

                {formData.bill_method === "PDC" && (
                  <>
                    <Col md={4}>
                      <Form.Label className="small fw-bold text-muted">Cheque Number</Form.Label>
                      <Form.Control
                        style={{ border: '1px solid rgb(77, 208, 225)' }}
                        type="number"
                        placeholder="Enter Cheque Number"
                        name="chequeno"
                        value={formData.chequeno}
                        onChange={handleInputChange}
                        onWheel={(e) => e.target.blur()}
                      />
                    </Col>
                    <Col md={4}>
                      <Form.Label className="small fw-bold text-muted">PDC Amount (₹)</Form.Label>
                      <Form.Control
                        style={{ border: '1px solid rgb(77, 208, 225)' }}
                        type="number"
                        placeholder="e.g. 100.00"
                        name="pdc"
                        value={formData.pdc}
                        onChange={handleInputChange}
                        onWheel={(e) => e.target.blur()}
                      />
                    </Col>
                  </>
                )}

                {formData.bill_Type === "non_insurance" && (
                  <Col md={4}>
                    <Form.Label className="small fw-bold text-muted">Discount Amount</Form.Label>
                    <Form.Control style={{ border: '1px solid rgb(77, 208, 225)' }} type="number" name="discount" placeholder="e.g. 100.00" value={formData.discount} onChange={handleInputChange} onWheel={(e) => e.target.blur()} />
                  </Col>
                )}

                {formData.bill_Type === "charity" && (
                  <Col md={4}>
                    <Form.Label className="small fw-bold text-muted">Charity Discount</Form.Label>
                    <Form.Control style={{ border: '1px solid rgb(77, 208, 225)' }} type="number" placeholder="e.g. 100.00" name="discountAmount" value={formData.discountAmount} onChange={handleInputChange} />
                  </Col>
                )}

                <Col md={8}>
                  <Form.Label className="small fw-bold text-muted">Note</Form.Label>
                  <Form.Control style={{ border: '1px solid rgb(77, 208, 225)' }} as="textarea" rows={2} name="note" placeholder="Enter a note" value={formData.note} onChange={handleInputChange} />
                </Col>
              </Row>

              {/* <div className="mt-5 p-4" style={{ backgroundColor: "#f8f9fa", borderRadius: "10px", border: "1px dashed #cbd5e0" }}>
                <Row className="justify-content-center text-center">
                  <Col md={4} className="border-end">
                    <span className="text-info d-block small fw-bold text-uppercase">Sub Total</span>
                    <h2 className="mb-0 fw-bold">₹ {formData.Sub_Total}</h2>
                  </Col>
                  <Col md={4}>
                    <span className="text-info d-block small fw-bold text-uppercase">Payable Amount</span>
                    <h2 className="mb-0 fw-bold" style={{ color: "#00838f" }}>₹ {formData.payableAmount}</h2>
                  </Col>
                </Row>
              </div> */}

              <div className="mt-4 p-3" style={{ backgroundColor: "#e0f7fa", borderRadius: "8px", border: "1px dashed #00bcd4" }}>
                <Row>
                  <Col md={12} className="text-end">
                    <div className="mb-2" style={{ borderBottom: "1px solid #b2ebf2", paddingBottom: "10px" }}>
                      <h6 style={{ fontSize: "14px", textAlign: "left", color: "#00838f", marginBottom: "10px", fontWeight: "bold" }}>
                        Detailed Charge Breakdown:
                      </h6>

                      {formData.dynamicRows.map((item, idx) => (
                        <div key={idx} style={{ fontSize: "14px", color: "#555", display: "flex", justifyContent: "space-between" }}>
                          <span>{item.label || `Item ${idx + 1}`} :</span>
                          <span>₹ {parseFloat(item.value || 0).toFixed(2)}</span>
                        </div>
                      ))}
                    </div>

                    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end" }}>
                      <div className="mb-5" style={{ fontSize: "15px", color: "#555" }}>Subtotal: <strong>₹ {getChargeBreakdown().subTotal}</strong></div>
                      <div style={{ fontSize: "15px", color: "#d32f2f" }}>Discount: <strong>- ₹ {getChargeBreakdown().discount}</strong></div>
                      <div style={{ fontSize: "20px", color: "#00838f", fontWeight: "bold", marginTop: "10px", borderTop: "2px solid #00bcd4", paddingTop: "5px" }}>
                        Total Payable: ₹ {getChargeBreakdown().payable}
                      </div>
                    </div>
                  </Col>
                </Row>
              </div>
            </Card.Body>
          </Card>
           <Card style={cardStyle}>
          <div className="d-flex justify-content-end gap-2" style={{margin:"10px"}}>
            <Button variant="secondary" size="lg" onClick={handleReset} style={{ padding: "10px 30px", borderRadius: "10px" }}>Reset</Button>
            <Button variant="primary" size="lg" type="submit" disabled={loading} style={{padding: "10px 40px", borderRadius: "10px", border: "none" }}>
              {loading ? "Adding..." : "Add Invoice"}
            </Button>
          </div>
          </Card>
        </Form>
      </Container>
    </div>
  );
};

export default AddInvoice;
// import React, { useState, useEffect, useCallback } from "react";
// import { Row, Col, Form, Container, Card, Button } from "react-bootstrap";
// import { useLocation, useParams } from "react-router-dom";
// import DatePicker from "react-datepicker";
// import FeatherIcon from "feather-icons-react";
// import "react-datepicker/dist/react-datepicker.css";
// import NavBarA from "../../components/NavbarA";
// import Swal from "sweetalert2";
// import "../../styles/styles.css";
// import { toast } from "react-hot-toast";
// import PageBreadcrumb from "../../components/PageBreadcrumb";
// import { decodeJwt } from "../../utils/decode-jwt";

// const Toast = Swal.mixin({
//   toast: true,
//   position: "top-end",
//   showConfirmButton: false,
//   timer: 3000,
//   timerProgressBar: true,
//   didOpen: (toast) => {
//     toast.addEventListener("mouseenter", Swal.stopTimer);
//     toast.addEventListener("mouseleave", Swal.resumeTimer);
//   },
// });

// const getCountryCode = (patient_phone) => {
//   if (!patient_phone) return "Unknown";

//   const country = countryCodes.find((code) =>
//     patient_phone.startsWith(code.value)
//   );
//   return country ? country.value : "Unknown";
// };

// function to24HourFormat(time12h) {
//   const [time, modifier] = time12h.trim().split(" ");
//   let [hours, minutes] = time.split(":").map(Number);

//   if (modifier.toUpperCase() === "PM" && hours !== 12) {
//     hours += 12;
//   }
//   if (modifier.toUpperCase() === "AM" && hours === 12) {
//     hours = 0;
//   }

//   return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
// }


// const countryCodes = [
//   { value: "+1", label: "🇺🇸 USA (+1)" },
//   { value: "+91", label: "🇮🇳 India (+91)" },
//   { value: "+44", label: "🇬🇧 UK (+44)" },
//   { value: "+61", label: "🇦🇺 Australia (+61)" },
//   { value: "+81", label: "🇯🇵 Japan (+81)" },
//   { value: "+49", label: "🇩🇪 Germany (+49)" },
//   { value: "+33", label: "🇫🇷 France (+33)" },
//   { value: "+971", label: "🇦🇪 UAE (+971)" },
//   { value: "+86", label: "🇨🇳 China (+86)" },
//   { value: "+55", label: "🇧🇷 Brazil (+55)" },
//   { value: "+27", label: "🇿🇦 South Africa (+27)" },
//   { value: "+34", label: "🇪🇸 Spain (+34)" },
// ];

// const countryNumberLimits = {
//   "+1": { min: 10, max: 10 },
//   "+91": { min: 10, max: 10 },
//   "+44": { min: 10, max: 10 },
//   "+61": { min: 9, max: 9 },
//   "+81": { min: 10, max: 10 },
//   "+49": { min: 10, max: 11 },
//   "+33": { min: 9, max: 9 },
//   "+971": { min: 9, max: 9 },
//   "+86": { min: 11, max: 11 },
//   "+55": { min: 10, max: 11 },
//   "+27": { min: 9, max: 9 },
//   "+34": { min: 9, max: 9 },
//   default: { min: 7, max: 15 },
// };

// const BASE_URL = "http://localhost:5100/api";

// export default function Add_appointment() {
//   const [loading, setLoading] = useState(false);
//   const [doctors, setDoctors] = useState([]);
//   const [fdeList, setFdeList] = useState([]);
//   const [treatmentList, setTreatmentList] = useState([]);
//   const [departmentList, setDepartmentList] = useState([]);
//   const [isExistingPatient, setIsExistingPatient] = useState(false);
//   const [noPendingAppt, setNoPendingAppt] = useState(true);
//   const [type, setType] = useState("");
//   const location = useLocation();
//   const { phone } = useParams();
//   const [currentLocation, setCurrentLocation] = useState(null);
//   const [formData, setFormData] = useState({
//     treatment: "",
//     date: new Date().toISOString().split("T")[0],
//     patientName: "",
//     reference: "",
//     patient_phone: "",
//     patient_location: "",
//     patient_type: "",
//     appointmentTime: "",
//     note: "",
//     FDE_Name: "",
//     departmentName: "",
//     doctorName: "",
//     doctor_id: "",
//     consultationchk: 0,
//     confirm_time: 0,
//     status: "BOOKED",
//     patient_id: "",
//   });
//   const [errors, setErrors] = useState({});
//   const newPatientTypes = ["NEW"];
//   const existingPatientTypes = ["FOLLOW", "POSTOPERATIVE", "OTHER"];

//   useEffect(() => {
//     const token = localStorage.getItem("token");
//     if (token) {
//       const payload = decodeJwt(token);
//       if (payload && payload.jobLocation) {
//         setCurrentLocation(payload.jobLocation);
//       }
//     }
//   }, []);

//   const fetchPatientDetails = useCallback(
//     async (patient_phone) => {
//       if (!patient_phone || !currentLocation) {
//         setIsExistingPatient(false);
//         setFormData((prev) => ({
//           ...prev,
//           patientName: "",
//           patient_location: "",
//           patient_id: "",
//           appointmentTime: new Date().toLocaleTimeString("en-US", {
//             hour: "2-digit",
//             minute: "2-digit",
//             hour12: true,
//           }),
//           note: "",
//           FDE_Name: "",
//           departmentName: "",
//           doctorName: "",
//           patient_type: "NEW",
//           doctor_id: "",
//         }));
//         return;
//       }

//       console.log("Fetching patient details...");

//       try {
//         const url = `${BASE_URL}/V1/appointment/getPatientByMobile?patient_phone=${patient_phone}&location=${currentLocation}`;
//         const response = await fetch(url, {
//           method: "GET",
//           headers: { "Content-Type": "application/json" },
//         });

//         if (!response.ok) {
//           setIsExistingPatient(false);
//           setFormData((prev) => ({
//             ...prev,
//             patientName: "",
//             patient_id: "",
//             patient_location: "",
//             patient_type: "NEW",
//             doctor_id: "",
//           }));
//           return;
//         }

//         const data = await response.json();
//         if (data.statusCode === 200 && data.data) {
//           setIsExistingPatient(true);

//           // Nested try block
//           try {
//             const confirmUrl = `${BASE_URL}/V1/appointment/getPatientByApptConfirm?patient_phone=${patient_phone}&location=${currentLocation}`;
//             const confirmResponse = await fetch(confirmUrl, {
//               method: "GET",
//               headers: { "Content-Type": "application/json" },
//             });

//             const confirmData = await confirmResponse.json();

//             // If the status is 400, it means a pending appointment was found
//             if (confirmResponse.status === 400) {
//               Swal.fire({
//                 icon: "warning",
//                 title: "Duplicate Appointment",
//                 text: confirmData.message || "This patient already has a pending appointment. Please complete it first.",
//                 confirmButtonColor: "#f39c12",
//               });

//               // Optionally: Stop the form from auto-filling or disable the submit button
//               setNoPendingAppt(false); // Or a specific state like setHasPendingAppt(true)
//               return; // Exit the function to prevent further processing
//             }
//             setNoPendingAppt(true);
//             if (!confirmResponse.ok) {
//               console.warn("Appointment confirmation fetch returned an error:", confirmResponse.status);
//             } else {
//               console.log("Eligibility check passed: No pending appointments.");
//             }

//           } catch (innerError) {
//             console.error("Error in confirmation check API call:", innerError);
//           }

//           Swal.fire({
//             icon: "info",
//             title: "Patient Found",
//             text: `${data.data.name} is already registered.`,
//             confirmButtonColor: "#00bcd4",
//             timer: 3000,
//           });

//           setFormData((prev) => ({
//             ...prev,
//             patientName: data.data.name || "",
//             patient_location: data.data.address || "",
//             patient_id: data.data.patient_id || "",
//             appointmentTime: data.data.appointmentTime || "",
//             note: data.data.note || "",
//             FDE_Name: data.data.FDE_Name || "",
//             departmentName: data.data.departmentName || "",
//             doctorName: data.data.doctorName || "",
//             patient_type: "",
//             doctor_id: data.data.doctor_id || "",
//           }));
//         } else {
//           setIsExistingPatient(false);
//           setFormData((prev) => ({
//             ...prev,
//             patientName: "",
//             patient_id: "",
//             patient_type: "NEW",
//             doctor_id: "",
//           }));
//         }
//       } catch (error) {
//         console.error("Error fetching patient details:", error);
//         setIsExistingPatient(false);
//         setFormData((prev) => ({
//           ...prev,
//           patientName: "",
//           patient_id: "",
//           patient_type: "NEW",
//           doctor_id: "",
//         }));
//       }
//     },
//     [currentLocation]
//   );

//   const fetchDropdownData = useCallback(async () => {
//     if (!currentLocation) return;

//     console.log("Fetching dropdown data...");

//     try {
//       const fetchApi = async (endpoint) => {
//         const url = `${BASE_URL}/V1/appointment/${endpoint}?location=${currentLocation}`;
//         const response = await fetch(url, {
//           method: "GET",
//           headers: { "Content-Type": "application/json" },
//         });
//         return response.ok ? response.json() : { data: [] };
//       };

//       const [treatmentData, doctorData, fdeData, departmentData] =
//         await Promise.all([
//           fetchApi("treatmentDropdown").then((res) => res.data),
//           fetchApi("doctorDropdown").then((res) => res.data),
//           fetchApi("fdeDropdown").then((res) => res.data),
//         ]);

//       setTreatmentList(Array.isArray(treatmentData) ? treatmentData : []);
//       setDoctors(Array.isArray(doctorData) ? doctorData : []);
//       setFdeList(Array.isArray(fdeData) ? fdeData : []);
//     } catch (error) {
//       console.error("Error fetching dropdown data:", error.message);
//     }
//   }, [currentLocation]);

//   const handleReset = () => {
//     setFormData({
//       treatment: "",
//       date: new Date().toISOString().split("T")[0],
//       patientName: "",
//       reference: "",
//       patient_phone: "",
//       patient_location: "",
//       patient_type: "",
//       appointmentTime: new Date().toLocaleTimeString("en-US", {
//         hour: "2-digit",
//         minute: "2-digit",
//         hour12: true,
//       }),
//       note: "",
//       FDE_Name: "",
//       departmentName: "",
//       doctorName: "",
//       doctor_id: "",
//       consultationchk: 0,
//       confirm_time: 0,
//       status: "BOOKED",
//       patient_id: "",
//     });

//     setIsExistingPatient(false);
//     setErrors({});
//     setType("");

//     Toast.fire({
//       icon: "success",
//       title: "Form reset successful",
//     });
//   };

//   useEffect(() => {
//     if (phone && currentLocation) {
//       fetchPatientDetails(phone);
//     }
//   }, [phone, currentLocation, fetchPatientDetails]);

//   useEffect(() => {
//     const currentTime = new Date().toLocaleTimeString("en-US", {
//       hour: "2-digit",
//       minute: "2-digit",
//       hour12: true,
//     });
//     setFormData((prev) => ({
//       ...prev,
//       appointmentTime: currentTime,
//     }));
//   }, []);

//   useEffect(() => {
//     if (currentLocation) {
//       fetchDropdownData();
//     }
//   }, [currentLocation, fetchDropdownData]);

//   const handleInputChange = (e) => {
//     const { name, value, tagName } = e.target;

//     if (name === "doctorName") {
//       const selectedDoctor = doctors.find((d) => d.name === value);

//       setFormData((prevState) => ({
//         ...prevState,
//         doctorName: value,
//         doctor_id: selectedDoctor ? selectedDoctor.doctor_id : "",
//       }));
//       return;
//     }

//     if (name === "patientName") {
//       const alphabetsOnly = value.replace(/[^A-Za-z\s]/g, "");
//       setFormData((prevState) => ({
//         ...prevState,
//         [name]:
//           tagName === "INPUT" ? alphabetsOnly.toUpperCase() : alphabetsOnly,
//       }));
//       return;
//     }

//     if (name === "patient_location") {
//       const validAddressChars = value.replace(/[^A-Za-z0-9\s,.\-/#]/g, "");
//       setFormData((prevState) => ({
//         ...prevState,
//         [name]:
//           tagName === "INPUT"
//             ? validAddressChars.toUpperCase()
//             : validAddressChars,
//       }));
//       return;
//     }

//     setFormData((prevState) => ({
//       ...prevState,
//       [name]: tagName === "INPUT" ? value.toUpperCase() : value,
//     }));
//   };

//   const phoneRegex = /^[0-9]{7,15}$/;

//   const validate = () => {
//     const newErrors = {};
//     const requiredFields = [
//       "date",
//       "patientName",
//       "patient_type",
//       "patient_phone",
//       "appointmentTime",
//       "note",
//       "FDE_Name",
//       "reference",
//       "doctor_id",
//     ];

//     if (shouldShowAddressAndReference()) {
//       requiredFields.push("patient_location");
//     }

//     if (formData.patient_type === "OTHER") {
//       requiredFields.push("treatment");
//     }

//     if (formData.patient_type !== "NEW" && !formData.patient_id) {
//       newErrors.patient_phone =
//         "Patient ID is required for existing patient types (FOLLOW, POSTOPERATIVE, OTHER). Please search by phone number.";
//     }

//     requiredFields.forEach((field) => {
//       if (!formData[field]) {
//         let displayName = field.replace(/([A-Z])/g, " $1");
//         if (field === "treatment") displayName = "Treatment";
//         if (field === "patient_location")
//           displayName = "Address (Patient Location)";
//         if (field === "doctor_id") displayName = "Appointment With (Doctor)";

//         newErrors[
//           field === "doctor_id" ? "doctorName" : field
//         ] = `${displayName} is required`;
//       }
//     });

//     if (!formData.patient_phone || !phoneRegex.test(formData.patient_phone)) {
//       newErrors.patient_phone = "Enter a valid phone number (7-15 digits)";
//     }

//     if (!currentLocation) {
//       newErrors.location = "Location data is not available.";
//     }

//     return newErrors;
//   };

//   const handleSubmit = async (saveType) => {
//     const validationErrors = validate();
//     setErrors(validationErrors);

//     if (Object.keys(validationErrors).length === 0) {
//       setLoading(true);

//       const payload = {
//         doctor_id: formData.doctor_id,
//         patient_type: formData.patient_type,
//         patient_phone: formData.patient_phone,
//         appointment_timestamp: formData.date,
//         appointment_time: to24HourFormat(formData.appointmentTime),
//         patient_location: formData.patient_location,
//         FDE_Name: formData.FDE_Name,
//         treatment_name: formData.treatment,
//         note: formData.note,
//         patient_id: formData.patient_id || undefined,
//         confirm_time: formData.confirm_time || 0,
//         status: formData.status || "BOOKED",
//         is_deleted: 0,
//         consultationchk: formData.consultationchk,
//         patientName: formData.patientName,
//         reference: formData.reference,
//         clinic_location: currentLocation,
//         saveType,
//         countryCode: getCountryCode(formData.patient_phone),
//       };
//       console.log("Payoad:", payload);

//       console.log("Submitting appointment request.");

//       try {
//         const response = await fetch(
//           `${BASE_URL}/V1/appointment/addAppointment?location=${currentLocation}`,
//           {
//             method: "POST",
//             headers: { "Content-Type": "application/json" },
//             body: JSON.stringify(payload),
//           }
//         );

//         if (response.ok) {
//           Swal.fire({
//             icon: "success",
//             title: "Success!",
//             text: "Appointment booked successfully.",
//             confirmButtonColor: "#00bcd4",
//           });
//           setFormData({
//             treatment: "",
//             date: new Date().toISOString().split("T")[0],
//             patientName: "",
//             patient_phone: "",
//             patient_location: "",
//             patient_type: "",
//             appointmentTime: "",
//             note: "",
//             FDE_Name: "",
//             departmentName: "",
//             doctorName: "",
//             doctor_id: "",
//             consultationchk: 0,
//             confirm_time: 0,
//             status: "BOOKED",
//             patient_id: "",
//           });
//         } else {
//           const errorData = await response.json();
//           console.error(`Backend error: ${errorData.message}`);
//           Swal.fire({
//             icon: "error",
//             title: "Booking Failed",
//             text: errorData.message || "Failed to book appointment",
//           });
//         }
//       } catch (error) {
//         console.error("Error adding appointment:", error.message);
//         Swal.fire({
//           icon: "error",
//           title: "Error",
//           text: "A network error occurred.",
//         });
//       } finally {
//         setLoading(false);
//       }
//     } else {
//       Toast.fire({
//         icon: "warning",
//         title: "Please fill all required fields",
//       });
//     }
//   };

//   const shouldShowAddressAndReference = () => {
//     return !(
//       isExistingPatient &&
//       (formData.patient_type === "FOLLOW" ||
//         formData.patient_type === "POSTOPERATIVE" ||
//         formData.patient_type === "OTHER")
//     );
//   };

//   const generateTimeSlots = () => {
//     const slots = [];
//     const startTime = new Date();
//     const endTime = new Date();
//     endTime.setHours(23, 45, 0);

//     const isToday = formData.date === new Date().toISOString().split("T")[0];

//     if (isToday) {
//       startTime.setHours(
//         new Date().getHours(),
//         Math.ceil(new Date().getMinutes() / 15) * 15,
//         0
//       );
//     } else {
//       startTime.setHours(7, 0, 0);
//     }

//     while (startTime <= endTime) {
//       const timeString = startTime.toLocaleTimeString("en-US", {
//         hour: "2-digit",
//         minute: "2-digit",
//         hour12: true,
//       });
//       slots.push(timeString);
//       startTime.setMinutes(startTime.getMinutes() + 15);
//     }

//     return slots;
//   };

//   const timeSlots = generateTimeSlots();

//   const handleDateChange = (date) => {
//     handleInputChange({
//       target: {
//         name: "date",
//         value: date ? date.toISOString().split("T")[0] : "",
//       },
//     });
//   };

//   const handlePhoneNumberChange = (e) => {
//     const patient_phone = e.target.value.replace(/\D/g, "");
//     const selectedCountryCode = "+91";
//     const limits =
//       countryNumberLimits[selectedCountryCode] || countryNumberLimits.default;

//     if (patient_phone.length <= limits.max) {
//       setFormData((prev) => ({
//         ...prev,
//         patient_phone: patient_phone,
//       }));

//       if (patient_phone.length === limits.max && currentLocation) {
//         fetchPatientDetails(patient_phone);
//       } else {
//         setIsExistingPatient(false);
//         setFormData((prev) => ({
//           ...prev,
//           patientName: "",
//           patient_type: "NEW",
//           doctor_id: "",
//           patient_id: "",
//         }));
//       }
//     }
//   };

//   const labelStyle = "fw-bold text-muted small uppercase mb-2";
//   const inputStyle = {
//     borderRadius: "8px",
//     border: "2px solid rgb(77, 208, 225)",
//     padding: "6px",
//   };

//   return (
//     <div
//       className="themebody-wrap"
//       style={{
//         background: "linear-gradient(to right, #e0f7fa, #80deea)",
//         minHeight: "100vh",
//         padding: "12px",
//         fontFamily: "'Poppins', Arial, sans-serif",
//       }}
//     >
//       <PageBreadcrumb pagename="Add Appointment Form" />
//       <NavBarA pagename="Add Appointment" />
//       <Container fluid>
//         <Row>
//           <Col>
//             <Card
//               style={{
//                 borderRadius: "15px",
//                 boxShadow: "0 10px 25px rgba(0, 0, 0, 0.08)",
//                 border: "none",
//                 background: "white",
//                 overflow: "hidden",
//               }}
//             >
//               <div
//                 style={{
//                   backgroundColor: "#67c5cfff",
//                   padding: "20px 25px",
//                   borderBottom: "2px solid #1a5b61ff",
//                   display: "flex",
//                   alignItems: "center",
//                 }}
//               >
//                 <FeatherIcon
//                   icon="calendar"
//                   size="24"
//                   style={{ color: "#1a5b61ff", marginRight: "12px" }}
//                 />
//                 <h4
//                   className="m-0"
//                   style={{
//                     color: "#1a5b61ff",
//                     fontWeight: "600",
//                     fontSize: "1.25rem",
//                   }}
//                 >
//                   Add New Appointment Details
//                 </h4>
//               </div>

//               <Card.Body style={{ padding: "20px" }}>
//                 <Form>
//                   {errors.location && (
//                     <div
//                       className="alert alert-danger py-2 px-3 mb-4"
//                       style={{ borderRadius: "8px" }}
//                     >
//                       <FeatherIcon
//                         icon="alert-circle"
//                         size="18"
//                         className="me-2"
//                       />
//                       {errors.location}
//                     </div>
//                   )}

//                   <Row className="g-4 mb-4">
//                     <Col md={3}>
//                       <Form.Group>
//                         <Form.Label className="fw-bold text-muted small uppercase mb-2">
//                           Contact Number <span className="text-danger">*</span>
//                         </Form.Label>
//                         <Form.Control
//                           type="tel"
//                           name="patient_phone"
//                           style={{
//                             borderRadius: "8px",
//                             border: "2px solid rgb(77, 208, 225)",
//                             padding: "6px",
//                           }}
//                           value={formData.patient_phone}
//                           onChange={handlePhoneNumberChange}
//                           placeholder={`Enter ${countryNumberLimits["+91"].max} digits Contact Number`}
//                           maxLength={countryNumberLimits["+91"].max}
//                         />
//                         {errors.patient_phone && (
//                           <p className="text-danger small mt-1">
//                             {errors.patient_phone}
//                           </p>
//                         )}
//                       </Form.Group>
//                     </Col>

//                     <Col md={3}>
//                       <Form.Group>
//                         <Form.Label className="fw-bold text-muted small uppercase mb-2">
//                           Patient Type <span className="text-danger">*</span>
//                         </Form.Label>
//                         <Form.Select
//                           name="patient_type"
//                           style={{
//                             borderRadius: "8px",
//                             border: "2px solid rgb(77, 208, 225)",
//                             padding: "6px",
//                           }}
//                           value={formData.patient_type}
//                           onChange={(e) => {
//                             setType(e.target.value);
//                             setFormData((prev) => ({
//                               ...prev,
//                               patient_type: e.target.value,
//                             }));
//                           }}
//                         >
//                           <option value="">Select Type</option>
//                           {(isExistingPatient
//                             ? existingPatientTypes
//                             : newPatientTypes
//                           ).map((type, index) => (
//                             <option key={index} value={type}>
//                               {type}
//                             </option>
//                           ))}
//                         </Form.Select>
//                         {errors.patient_type && (
//                           <p className="text-danger small mt-1">
//                             {errors.patient_type}
//                           </p>
//                         )}
//                       </Form.Group>
//                     </Col>

//                     <Col md={3}>
//                       <Form.Group>
//                         <Form.Label className="fw-bold text-muted small uppercase mb-2">
//                           Appointment Date{" "}
//                           <span className="text-danger">*</span>
//                         </Form.Label>
//                         <div className="custom-datepicker-wrapper">
//                           <DatePicker
//                             selected={
//                               formData.date ? new Date(formData.date) : null
//                             }
//                             onChange={handleDateChange}
//                             className="form-control custom-datepicker"
//                             style={{
//                               borderRadius: "8px",
//                               border: "2px solid rgb(77, 208, 225)",
//                             }}
//                             dateFormat="dd-MM-yyyy"
//                             placeholderText="Select Date"
//                           />
//                         </div>
//                         {errors.date && (
//                           <p className="text-danger small mt-1">
//                             {errors.date}
//                           </p>
//                         )}
//                       </Form.Group>
//                     </Col>

//                     <Col md={3}>
//                       <Form.Group>
//                         <Form.Label className="fw-bold text-muted small uppercase mb-2">
//                           Appointment Time{" "}
//                           <span className="text-danger">*</span>
//                         </Form.Label>
//                         <Form.Select
//                           name="appointmentTime"
//                           style={{
//                             borderRadius: "8px",
//                             border: "2px solid rgb(77, 208, 225)",
//                           }}
//                           value={formData.appointmentTime}
//                           onChange={handleInputChange}
//                         >
//                           <option value="">Select Time</option>
//                           {timeSlots.map((time, index) => (
//                             <option key={index} value={time}>
//                               {time}
//                             </option>
//                           ))}
//                         </Form.Select>
//                         {errors.appointmentTime && (
//                           <p className="text-danger small mt-1">
//                             {errors.appointmentTime}
//                           </p>
//                         )}
//                       </Form.Group>
//                     </Col>
//                   </Row>

//                   <Row className="g-4 mb-4">
//                     <Col md={4}>
//                       <Form.Group>
//                         <Form.Label className="fw-bold text-muted small uppercase mb-2">
//                           Patient Name <span className="text-danger">*</span>
//                         </Form.Label>
//                         <Form.Control
//                           type="text"
//                           name="patientName"
//                           placeholder="Enter Patient Name"
//                           style={{
//                             borderRadius: "8px",
//                             border: "2px solid rgb(77, 208, 225)",
//                           }}
//                           value={formData.patientName}
//                           onChange={handleInputChange}
//                         />
//                         {errors.patientName && (
//                           <p className="text-danger small mt-1">
//                             {errors.patientName}
//                           </p>
//                         )}
//                       </Form.Group>
//                     </Col>

//                     {(formData.patient_type === "OTHER" ||
//                       formData.treatment) && (
//                       <Col md={4}>
//                         <Form.Group>
//                           <Form.Label className="fw-bold text-muted small uppercase mb-2">
//                             Treatment
//                           </Form.Label>
//                           <Form.Select
//                             name="treatment"
//                             style={{
//                               borderRadius: "8px",
//                               border: "2px solid rgb(77, 208, 225)",
//                             }}
//                             value={formData.treatment}
//                             onChange={handleInputChange}
//                             disabled={!currentLocation}
//                           >
//                             <option value="">Select Treatment</option>
//                             {treatmentList?.map((t) => (
//                               <option
//                                 key={t.treatment_name}
//                                 value={t.treatment_name}
//                               >
//                                 {t.treatment_name}
//                               </option>
//                             ))}
//                           </Form.Select>
//                         </Form.Group>
//                       </Col>
//                     )}

//                     {shouldShowAddressAndReference() && (
//                       <Col
//                         md={
//                           formData.patient_type === "OTHER" ||
//                           formData.treatment
//                             ? 4
//                             : 8
//                         }
//                       >
//                         <Form.Group>
//                           <Form.Label className="fw-bold text-muted small uppercase mb-2">
//                             Patient Address{" "}
//                             <span className="text-danger">*</span>
//                           </Form.Label>
//                           <Form.Control
//                             type="text"
//                             name="patient_location"
//                             placeholder="Enter Patient Address"
//                             style={{
//                               borderRadius: "8px",
//                               border: "2px solid rgb(77, 208, 225)",
//                             }}
//                             value={formData.patient_location}
//                             onChange={handleInputChange}
//                           />
//                           {errors.patient_location && (
//                             <p className="text-danger small mt-1">
//                               {errors.patient_location}
//                             </p>
//                           )}
//                         </Form.Group>
//                       </Col>
//                     )}

//                     <Col md={4}>
//                       <Form.Group>
//                         <Form.Label className="fw-bold text-muted small uppercase mb-2">
//                           Doctor Name <span className="text-danger">*</span>
//                         </Form.Label>
//                         <Form.Select
//                           name="doctorName"
//                           style={{
//                             borderRadius: "8px",
//                             border: "2px solid rgb(77, 208, 225)",
//                           }}
//                           value={formData.doctorName}
//                           onChange={handleInputChange}
//                           disabled={!currentLocation}
//                         >
//                           <option value="">Select Doctor</option>
//                           {doctors?.map((doctor) => (
//                             <option key={doctor.doctor_id} value={doctor.name}>
//                               {doctor.name}
//                             </option>
//                           ))}
//                         </Form.Select>
//                         {errors.doctorName && (
//                           <p className="text-danger small mt-1">
//                             {errors.doctorName}
//                           </p>
//                         )}
//                       </Form.Group>
//                     </Col>

//                     <Col md={4}>
//                       <Form.Group>
//                         <Form.Label className="fw-bold text-muted small uppercase mb-2">
//                           FDE Name <span className="text-danger">*</span>
//                         </Form.Label>
//                         <Form.Select
//                           name="FDE_Name"
//                           style={{
//                             borderRadius: "8px",
//                             border: "2px solid rgb(77, 208, 225)",
//                           }}
//                           value={formData.FDE_Name}
//                           onChange={handleInputChange}
//                           disabled={!currentLocation}
//                         >
//                           <option value="">Select FDE...</option>
//                           {fdeList?.map((fde) => (
//                             <option key={fde.FDEID} value={fde.FDEID}>
//                               {fde.FDEName}
//                             </option>
//                           ))}
//                         </Form.Select>
//                         {errors.FDE_Name && (
//                           <p className="text-danger small mt-1">
//                             {errors.FDE_Name}
//                           </p>
//                         )}
//                       </Form.Group>
//                     </Col>
//                     <Col md={4}>
//                       <Form.Group>
//                         <Form.Label className={labelStyle}>
//                           Reference <span className="text-danger">*</span>
//                         </Form.Label>
//                         <Form.Select
//                           name="reference"
//                           style={inputStyle}
//                           value={formData.reference}
//                           onChange={handleInputChange}
//                         >
//                           <option value="">Select Reference</option>
//                           {[
//                             "Family / Friends",
//                             "Referred By Another Doctor",
//                             "Referred By Another Patient",
//                             "Internet",
//                             "Social Media",
//                             "Entertainment Media",
//                             "TV Show",
//                             "Newspaper / Magazine",
//                             "Awareness Lecture",
//                             "HHC Board on building",
//                             "I was treated here in past ",
//                             "Healing Hands Clinic Branch",
//                             "Aggregators",
//                             "Other",
//                           ].map((ref) => (
//                             <option key={ref} value={ref}>
//                               {ref}
//                             </option>
//                           ))}
//                         </Form.Select>
//                         {errors.reference && (
//                           <p className="text-danger small mt-1">
//                             {errors.reference}
//                           </p>
//                         )}
//                       </Form.Group>
//                     </Col>
//                     <Col md={8} className="mb-10">
//                       <Form.Group>
//                         <Form.Label className="fw-bold text-muted small uppercase mb-2">
//                           Note{" "}
//                         </Form.Label>
//                         <Form.Control
//                           as="textarea"
//                           rows={3}
//                           name="note"
//                           placeholder="Enter additional remarks..."
//                           style={{
//                             borderRadius: "10px",
//                             padding: "5px",
//                             border: "2px solid rgb(77, 208, 225)",
//                           }}
//                           value={formData.note}
//                           onChange={handleInputChange}
//                         />
//                         {errors.note && (
//                           <p className="text-danger small mt-1">
//                             {errors.note}
//                           </p>
//                         )}
//                       </Form.Group>
//                     </Col>
//                   </Row>

//                   <div className="d-flex justify-content-end align-items-center">
//                     <Button
//                       style={{ borderRadius: "10px" }}
//                       variant="secondary"
//                       className="me-2 "
//                       onClick={handleReset}
//                     >
//                       Reset Form
//                     </Button>
//                     <Button
//                       className="px-4 py-13"
//                       style={{
//                         borderRadius: "10px",
//                         backgroundColor: "#00bcd4",
//                         border: "none",
//                         fontWeight: "600",
//                       }}
//                       onClick={() => handleSubmit("save")}
//                       disabled={loading || !currentLocation || !noPendingAppt}
//                     >
//                       {loading ? <>Adding...</> : "Add Appointment"}
//                     </Button>
//                   </div>
//                 </Form>
//               </Card.Body>
//             </Card>
//           </Col>
//         </Row>
//       </Container>
//     </div>
//   );
// }












import React, { useState, useEffect, useCallback } from "react";
import { Row, Col, Form, Container, Card, Button } from "react-bootstrap";
import { useLocation, useParams } from "react-router-dom";
import DatePicker from "react-datepicker";
import FeatherIcon from "feather-icons-react";
import "react-datepicker/dist/react-datepicker.css";
import NavBarA from "../../components/NavbarA";
import Swal from "sweetalert2";
import "../../styles/styles.css";
import { toast } from "react-hot-toast";
import PageBreadcrumb from "../../components/PageBreadcrumb";
import { decodeJwt } from "../../utils/decode-jwt";

const Toast = Swal.mixin({
  toast: true,
  position: "top-end",
  showConfirmButton: false,
  timer: 3000,
  timerProgressBar: true,
  didOpen: (toast) => {
    toast.addEventListener("mouseenter", Swal.stopTimer);
    toast.addEventListener("mouseleave", Swal.resumeTimer);
  },
});

const getCountryCode = (patient_phone) => {
  if (!patient_phone) return "Unknown";

  const country = countryCodes.find((code) =>
    patient_phone.startsWith(code.value)
  );
  return country ? country.value : "Unknown";
};

function to24HourFormat(time12h) {
  const [time, modifier] = time12h.trim().split(" ");
  let [hours, minutes] = time.split(":").map(Number);

  if (modifier.toUpperCase() === "PM" && hours !== 12) {
    hours += 12;
  }
  if (modifier.toUpperCase() === "AM" && hours === 12) {
    hours = 0;
  }

  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

const countryCodes = [
  { value: "+1", label: "🇺🇸 USA (+1)" },
  { value: "+91", label: "🇮🇳 India (+91)" },
  { value: "+44", label: "🇬🇧 UK (+44)" },
  { value: "+61", label: "🇦🇺 Australia (+61)" },
  { value: "+81", label: "🇯🇵 Japan (+81)" },
  { value: "+49", label: "🇩🇪 Germany (+49)" },
  { value: "+33", label: "🇫🇷 France (+33)" },
  { value: "+971", label: "🇦🇪 UAE (+971)" },
  { value: "+86", label: "🇨🇳 China (+86)" },
  { value: "+55", label: "🇧🇷 Brazil (+55)" },
  { value: "+27", label: "🇿🇦 South Africa (+27)" },
  { value: "+34", label: "🇪🇸 Spain (+34)" },
];

const countryNumberLimits = {
  "+1": { min: 10, max: 10 },
  "+91": { min: 10, max: 10 },
  "+44": { min: 10, max: 10 },
  "+61": { min: 9, max: 9 },
  "+81": { min: 10, max: 10 },
  "+49": { min: 10, max: 11 },
  "+33": { min: 9, max: 9 },
  "+971": { min: 9, max: 9 },
  "+86": { min: 11, max: 11 },
  "+55": { min: 10, max: 11 },
  "+27": { min: 9, max: 9 },
  "+34": { min: 9, max: 9 },
  default: { min: 7, max: 15 },
};

const BASE_URL = "http://localhost:5100/api";

export default function Add_appointment() {
  const [loading, setLoading] = useState(false);
  const [doctors, setDoctors] = useState([]);
  const [fdeList, setFdeList] = useState([]);
  const [treatmentList, setTreatmentList] = useState([]);
  const [departmentList, setDepartmentList] = useState([]);
  const [isExistingPatient, setIsExistingPatient] = useState(false);
  const [noPendingAppt, setNoPendingAppt] = useState(true);
  const [type, setType] = useState("");
  const location = useLocation();
  const { phone } = useParams();
  const [currentLocation, setCurrentLocation] = useState(null);
  const [formData, setFormData] = useState({
    treatment: "",
    date: new Date().toISOString().split("T")[0],
    patientName: "",
    reference: "",
    patient_phone: "",
    patient_location: "",
    patient_type: "",
    appointmentTime: "",
    note: "",
    FDE_Name: "",
    departmentName: "",
    doctorName: "",
    doctor_id: "",
    consultationchk: 0,
    confirm_time: 0,
    status: "BOOKED",
    patient_id: "",
  });
  const [errors, setErrors] = useState({});
  const newPatientTypes = ["NEW"];
  const existingPatientTypes = ["FOLLOW-UP", "POST-OPERATIVE", "OTHER"];

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      const payload = decodeJwt(token);
      if (payload && payload.jobLocation) {
        setCurrentLocation(payload.jobLocation);
      }
    }
  }, []);

  const fetchPatientDetails = useCallback(
    async (patient_phone) => {
      if (!patient_phone || !currentLocation) {
        setIsExistingPatient(false);
        setFormData((prev) => ({
          ...prev,
          patientName: "",
          patient_location: "",
          patient_id: "",
          appointmentTime: new Date().toLocaleTimeString("en-US", {
            hour: "2-digit",
            minute: "2-digit",
            hour12: true,
          }),
          note: "",
          FDE_Name: "",
          departmentName: "",
          doctorName: "",
          patient_type: "NEW",
          doctor_id: "",
        }));
        return;
      }

      try {
        const url = `${BASE_URL}/V1/appointment/getPatientByMobile?patient_phone=${patient_phone}&location=${currentLocation}`;
        const response = await fetch(url, {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        });

        if (!response.ok) {
          setIsExistingPatient(false);
          setFormData((prev) => ({
            ...prev,
            patientName: "",
            patient_id: "",
            patient_location: "",
            patient_type: "NEW",
            doctor_id: "",
          }));
          return;
        }

        const data = await response.json();
        if (data.statusCode === 200 && data.data) {
          setIsExistingPatient(true);

          try {
            const confirmUrl = `${BASE_URL}/V1/appointment/getPatientByApptConfirm?patient_phone=${patient_phone}&location=${currentLocation}`;
            const confirmResponse = await fetch(confirmUrl, {
              method: "GET",
              headers: { "Content-Type": "application/json" },
            });

            const confirmData = await confirmResponse.json();

            if (confirmResponse.status === 400) {
              Swal.fire({
                icon: "warning",
                title: "Duplicate Appointment",
                text: confirmData.message || "This patient already has a pending appointment.",
                confirmButtonColor: "#f39c12",
              });
              setNoPendingAppt(false);
              return;
            }
            setNoPendingAppt(true);
          } catch (innerError) {
            console.error("Error in confirmation check API call:", innerError);
          }

          Swal.fire({
            icon: "info",
            title: "Patient Found",
            text: `${data.data.name} is already registered.`,
            confirmButtonColor: "#00bcd4",
            timer: 3000,
          });

          setFormData((prev) => ({
            ...prev,
            patientName: data.data.name || "",
            patient_location: data.data.address || "",
            patient_id: data.data.patient_id || "",
            appointmentTime: data.data.appointmentTime || "",
            note: data.data.note || "",
            FDE_Name: data.data.FDE_Name || "",
            departmentName: data.data.departmentName || "",
            doctorName: data.data.doctorName || "",
            patient_type: "",
            doctor_id: data.data.doctor_id || "",
          }));
        } else {
          setIsExistingPatient(false);
          setFormData((prev) => ({
            ...prev,
            patientName: "",
            patient_id: "",
            patient_type: "NEW",
            doctor_id: "",
          }));
        }
      } catch (error) {
        console.error("Error fetching patient details:", error);
        setIsExistingPatient(false);
      }
    },
    [currentLocation]
  );

  const fetchDropdownData = useCallback(async () => {
    if (!currentLocation) return;
    try {
      const fetchApi = async (endpoint) => {
        const url = `${BASE_URL}/V1/appointment/${endpoint}?location=${currentLocation}`;
        const response = await fetch(url, {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        });
        return response.ok ? response.json() : { data: [] };
      };

      const [treatmentData, doctorData, fdeData] = await Promise.all([
        fetchApi("treatmentDropdown").then((res) => res.data),
        fetchApi("doctorDropdown").then((res) => res.data),
        fetchApi("fdeDropdown").then((res) => res.data),
      ]);

      setTreatmentList(Array.isArray(treatmentData) ? treatmentData : []);
      setDoctors(Array.isArray(doctorData) ? doctorData : []);
      setFdeList(Array.isArray(fdeData) ? fdeData : []);
    } catch (error) {
      console.error("Error fetching dropdown data:", error.message);
    }
  }, [currentLocation]);

  const handleManualReset = () => {
    handleReset();
    Toast.fire({ icon: "success", title: "Form reset successful" });
  };

  const handleReset = () => {
    setFormData({
      treatment: "",
      date: new Date().toISOString().split("T")[0],
      patientName: "",
      reference: "",
      patient_phone: "",
      patient_location: "",
      patient_type: "",
      appointmentTime: new Date().toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
      }),
      note: "",
      FDE_Name: "",
      departmentName: "",
      doctorName: "",
      doctor_id: "",
      consultationchk: 0,
      confirm_time: 0,
      status: "BOOKED",
      patient_id: "",
    });
    setIsExistingPatient(false);
    setErrors({});
    setType("");
  };

  useEffect(() => {
    if (phone && currentLocation) {
      fetchPatientDetails(phone);
    }
  }, [phone, currentLocation, fetchPatientDetails]);

  useEffect(() => {
    const currentTime = new Date().toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    });
    setFormData((prev) => ({ ...prev, appointmentTime: currentTime }));
  }, []);

  useEffect(() => {
    if (currentLocation) fetchDropdownData();
  }, [currentLocation, fetchDropdownData]);

  const handleInputChange = (e) => {
    const { name, value, tagName } = e.target;
    if (name === "doctorName") {
      const selectedDoctor = doctors.find((d) => d.name === value);
      setFormData((prevState) => ({
        ...prevState,
        doctorName: value,
        doctor_id: selectedDoctor ? selectedDoctor.doctor_id : "",
      }));
      return;
    }
    // const finalValue = (tagName === "INPUT" || tagName === "TEXTAREA") ? value.toUpperCase() : value;
    setFormData((prevState) => ({ ...prevState, [name]: value }));
  };

  // const validate = () => {
  //   const newErrors = {};
  //   const requiredFields = ["date", "patientName", "patient_type", "patient_phone", "appointmentTime", "note", "FDE_Name", "reference", "doctor_id"];
  //   if (!(isExistingPatient && (formData.patient_type === "FOLLOW" || formData.patient_type === "POSTOPERATIVE" || formData.patient_type === "OTHER"))) {
  //     requiredFields.push("patient_location");
  //   }
  //   if (formData.patient_type === "OTHER") requiredFields.push("treatment");

  //   requiredFields.forEach((field) => {
  //     if (!formData[field]) {
  //       newErrors[field === "doctor_id" ? "doctorName" : field] = "Required";
  //     }
  //   });
  //   return newErrors;
  // };

  const validate = () => {
    const newErrors = {};
    const requiredFields = ["date", "patientName", "patient_type", "patient_phone", "appointmentTime", "FDE_Name", "doctor_id"];

    if (formData.patient_type === "NEW") {
      requiredFields.push("patient_location");
      requiredFields.push("reference");
    }

    if (formData.patient_type === "OTHER") {
      requiredFields.push("treatment");
    }

    requiredFields.forEach((field) => {
      if (!formData[field]) {
        newErrors[field === "doctor_id" ? "doctorName" : field] = "Required";
      }
    });
    return newErrors;
  };

  const handleSubmit = async (saveType) => {
    const validationErrors = validate();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length === 0) {
      setLoading(true);
      const payload = {
        doctor_id: formData.doctor_id,
        patient_type: formData.patient_type,
        patient_phone: formData.patient_phone,
        appointment_timestamp: formData.date,
        appointment_time: to24HourFormat(formData.appointmentTime),
        patient_location: formData.patient_location,
        FDE_Name: formData.FDE_Name,
        treatment_name: formData.treatment,
        note: formData.note,
        patient_id: formData.patient_id || undefined,
        confirm_time: formData.confirm_time || 0,
        status: formData.status || "BOOKED",
        is_deleted: 0,
        consultationchk: formData.consultationchk,
        patientName: formData.patientName,
        reference: formData.reference,
        clinic_location: currentLocation,
        saveType,
        countryCode: getCountryCode(formData.patient_phone),
      };
      try {
        const response = await fetch(`${BASE_URL}/V1/appointment/addAppointment?location=${currentLocation}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        if (response.ok) {
          Swal.fire({ icon: "success", title: "Success!", text: "Appointment booked successfully." });
          handleReset();
        } else {
          const errorData = await response.json();
          Swal.fire({ icon: "error", title: "Booking Failed", text: errorData.message });
        }
      } catch (error) {
        Swal.fire({ icon: "error", title: "Error", text: "Network error occurred." });
      } finally {
        setLoading(false);
      }
    } else {
      Toast.fire({ icon: "warning", title: "Fill all required fields" });
    }
  };

  const generateTimeSlots = () => {
    const slots = [];
    const startTime = new Date();
    const endTime = new Date();
    endTime.setHours(23, 45, 0);
    startTime.setHours(7, 0, 0);
    while (startTime <= endTime) {
      slots.push(startTime.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: true }));
      startTime.setMinutes(startTime.getMinutes() + 15);
    }
    return slots;
  };

  const timeSlots = generateTimeSlots();

  const handlePhoneNumberChange = (e) => {
    const val = e.target.value.replace(/\D/g, "");
    if (val.length <= 10) {
      setFormData((prev) => ({ ...prev, patient_phone: val }));
      if (val.length === 10 && currentLocation) fetchPatientDetails(val);
    }
  };

  const labelStyle = {
    fontSize: "13px",
    fontWeight: "600",
    marginBottom: "5px",
    display: "block"
  };

  const inputStyle = {
    fontSize: "12px",
    borderRadius: "10px",
    border: "2px solid rgb(77, 208, 225)",
    padding: "5px 10px",
  };

  const cardHeaderStyle = {
    backgroundColor: "#67c5cfff",
    padding: "12px 20px",
    borderBottom: "2px solid #1a5b61ff",
    display: "flex",
    alignItems: "center",
  };

  return (
    <div
      className="themebody-wrap"
      style={{
        background: "linear-gradient(to right, #e0f7fa, #80deea)",
        minHeight: "100vh",
        padding: "10px",
        fontFamily: "'Poppins', sans-serif",
      }}
    >
      <PageBreadcrumb pagename="Add Appointment Form" />
      <NavBarA pagename="Add Appointment" />
      <Container fluid>
        <Row>
          <Col>
            <Card style={{ borderRadius: "15px", boxShadow: "0 10px 25px rgba(0,0,0,0.08)", border: "none", background: "white", overflow: "hidden" }}>
              <div style={cardHeaderStyle}>
                <FeatherIcon icon="plus-square" size="18" style={{ color: "#1a5b61ff", marginRight: "10px" }} />
                <h4 style={{ color: "#1a5b61ff", fontWeight: "600", fontSize: "1rem", margin: 0 }}>Add New Appointment Detail</h4>
              </div>

              <Card.Body style={{ padding: "10px" }}>
                <Form>
                  <Row className="g-3 mb-3">
                    <Col md={3}>
                      <Form.Label style={labelStyle}>Contact Number <span className="text-danger">*</span></Form.Label>
                      <Form.Control type="tel" style={inputStyle} value={formData.patient_phone} onChange={handlePhoneNumberChange} placeholder="Enter Contact Number" />
                      {errors.patient_phone && <p className="text-danger" style={{ fontSize: '11px' }}>{errors.patient_phone}</p>}
                    </Col>
                    <Col md={3}>
                      <Form.Label style={labelStyle}>Patient Type <span className="text-danger">*</span></Form.Label>
                      <Form.Select style={inputStyle} name="patient_type" value={formData.patient_type} onChange={handleInputChange}>
                        <option value="">Select Type</option>
                        {(isExistingPatient ? existingPatientTypes : newPatientTypes).map((t) => <option key={t} value={t}>{t}</option>)}
                      </Form.Select>
                    </Col>
                    <Col md={3}>
                      <Form.Label style={labelStyle}>Appointment Date <span className="text-danger">*</span></Form.Label>
                      {/* <Form.Control type="date" style={inputStyle} name="date" value={formData.date} minDate={new Date()} onChange={handleInputChange} /> */}
                      <Form.Control
                        type="date"
                        style={inputStyle}
                        name="date"
                        value={formData.date}
                        min={new Date().toISOString().split("T")[0]}
                        onChange={handleInputChange}
                      />
                    </Col>
                    <Col md={3}>
                      <Form.Label style={labelStyle}>Appointment Time <span className="text-danger">*</span></Form.Label>
                      <Form.Select style={inputStyle} name="appointmentTime" value={formData.appointmentTime} onChange={handleInputChange}>
                        <option value="">Select Time</option>
                        {timeSlots.map((t) => <option key={t} value={t}>{t}</option>)}
                      </Form.Select>
                    </Col>
                  </Row>

                  <Row className="g-3 mb-3">
                    <Col md={4}>
                      <Form.Label style={labelStyle}>Patient Name <span className="text-danger">*</span></Form.Label>
                      <Form.Control style={inputStyle} type="text" name="patientName" value={formData.patientName} onChange={handleInputChange} placeholder="Enter Name" />
                    </Col>
                    {(formData.patient_type === "OTHER" || formData.treatment) && (
                      <Col md={4}>
                        <Form.Label style={labelStyle}>Treatment <span className="text-danger">*</span></Form.Label>
                        <Form.Select style={inputStyle} name="treatment" value={formData.treatment} onChange={handleInputChange}>
                          <option value="">Select Treatment</option>
                          {treatmentList?.map((t) => <option key={t.treatment_name} value={t.treatment_name}>{t.treatment_name}</option>)}
                        </Form.Select>
                      </Col>
                    )}
                    {/* {!(isExistingPatient && (formData.patient_type === "FOLLOW" || formData.patient_type === "POSTOPERATIVE" || formData.patient_type === "OTHER")) && (
                      <Col md={formData.patient_type === "OTHER" ? 4 : 8}>
                        <Form.Label style={labelStyle}>Patient Address <span className="text-danger">*</span></Form.Label>
                        <Form.Control style={inputStyle} type="text" name="patient_location" value={formData.patient_location} onChange={handleInputChange} placeholder="Enter Address" />
                      </Col>
                    )} */}
                    {formData.patient_type === "NEW" && (
                      <Col md={8}>
                        <Form.Label style={labelStyle}>
                          Patient Address <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Control
                          style={inputStyle}
                          type="text"
                          name="patient_location"
                          value={formData.patient_location}
                          onChange={handleInputChange}
                          placeholder="Enter Address"
                        />
                        {errors.patient_location && (
                          <p className="text-danger" style={{ fontSize: "11px" }}>
                            {errors.patient_location}
                          </p>
                        )}
                      </Col>
                    )}
                    <Col md={4}>
                      <Form.Label style={labelStyle}>Doctor Name <span className="text-danger">*</span></Form.Label>
                      <Form.Select style={inputStyle} name="doctorName" value={formData.doctorName} onChange={handleInputChange}>
                        <option value="">Select Doctor</option>
                        {doctors?.map((d) => <option key={d.doctor_id} value={d.name}>{d.name}</option>)}
                      </Form.Select>
                    </Col>
                    <Col md={4}>
                      <Form.Label style={labelStyle}>FDE Name <span className="text-danger">*</span></Form.Label>
                      <Form.Select style={inputStyle} name="FDE_Name" value={formData.FDE_Name} onChange={handleInputChange}>
                        <option value="">Select FDE</option>
                        {fdeList?.map((f) => <option key={f.FDEID} value={f.FDEID}>{f.FDEName}</option>)}
                      </Form.Select>
                    </Col>
                    {/* <Col md={4}>
                      <Form.Label style={labelStyle}>Reference <span className="text-danger">*</span></Form.Label>
                      <Form.Select style={inputStyle} name="reference" value={formData.reference} onChange={handleInputChange}>
                        <option value="">Select Reference</option>
                        {["Family / Friends",
                            "Referred By Another Doctor",
                            "Referred By Another Patient",
                            "Internet",
                            "Social Media",
                            "Entertainment Media",
                            "TV Show",
                            "Newspaper / Magazine",
                            "Awareness Lecture",
                            "HHC Board on building",
                            "I was treated here in past ",
                            "Healing Hands Clinic Branch",
                            "Aggregators",
                            "Other",].map(r => <option key={r} value={r}>{r}</option>)}
                      </Form.Select>
                    </Col> */}
                    {formData.patient_type === "NEW" && (
                      <Col md={4}>
                        <Form.Label style={labelStyle}>
                          Reference <span className="text-danger">*</span>
                        </Form.Label>
                        <Form.Select
                          style={inputStyle}
                          name="reference"
                          value={formData.reference}
                          onChange={handleInputChange}
                        >
                          <option value="">Select Reference</option>
                          {[
                            "Family / Friends",
                            "Referred By Another Doctor",
                            "Referred By Another Patient",
                            "Internet",
                            "Social Media",
                            "Entertainment Media",
                            "TV Show",
                            "Newspaper / Magazine",
                            "Awareness Lecture",
                            "HHC Board on building",
                            "I was treated here in past ",
                            "Healing Hands Clinic Branch",
                            "Aggregators",
                            "Other",
                          ].map((r) => (
                            <option key={r} value={r}>
                              {r}
                            </option>
                          ))}
                        </Form.Select>
                        {errors.reference && (
                          <p className="text-danger" style={{ fontSize: "11px" }}>
                            {errors.reference}
                          </p>
                        )}
                      </Col>
                    )}
                    <Col md={4} className="mb-10">
                      <Form.Label style={labelStyle}>Note</Form.Label>
                      <Form.Control as="textarea" rows={2} style={{ ...inputStyle }} name="note" value={formData.note} onChange={handleInputChange} placeholder="Enter additional note..." />
                    </Col>
                  </Row>
                  <div className="d-flex justify-content-end" >
                    <Button variant="secondary" className="me-2" style={{ fontSize: "13px", borderRadius: "10px", padding: "10px 20px" }} onClick={handleManualReset}>Reset Form</Button>
                    <Button variant="primary" style={{ fontSize: "13px", borderRadius: "10px", padding: "10px 25px", border: "none" }} onClick={() => handleSubmit("save")} disabled={loading || !noPendingAppt}>
                      {loading ? "Adding..." : "Add Appointment"}
                    </Button>
                  </div>
                </Form>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}